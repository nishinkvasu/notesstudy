#include "vect_add_one.h"

void AddOneToEach(vector<int> &v) 
{
    for (auto& i: v) {
        i++;
    }
}
