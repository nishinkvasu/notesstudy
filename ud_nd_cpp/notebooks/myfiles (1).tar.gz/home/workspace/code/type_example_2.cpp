#include <iostream>
#include <string>
using std::cout;

int main() {
    // Declare and initialize j here.
    int j = 10;
    
    cout << j << std::endl;
}

