#include <iostream>
#include <vector>
using std::vector;
using std::cout;

int main() {
    // Declare and initialize a vector v here.
    vector<int> v;
    v = {6, 7, 8};
    cout << v.size() << std::endl;
}
