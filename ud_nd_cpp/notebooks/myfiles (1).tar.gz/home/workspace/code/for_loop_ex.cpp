#include <iostream>
using std::cout;

int main() {
    // Add your code here.
    for(auto i = -3; i <= 10; i++)
        cout << i << "\n";
    
}
