#include <iostream>
#include <vector>
using std::vector;
using std::cout;

int main() {
    auto i = 5;
    auto v_6 = {1, 2, 3};
    cout << "Variables declared and initialized without explicitly stating type!" << "\n";
    //for(i : v_6) cannot do like this.. since it uses auto for i & v_6
    for(auto j : v_6)
        cout << i << " ";
}
