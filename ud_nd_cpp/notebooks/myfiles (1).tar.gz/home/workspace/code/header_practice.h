// This file will be saved as "header_practice.h"
#ifndef HEADER_PRACTICE_H
#define HEADER_PRACTICE_H

#include <vector>
using std::vector;

int IncrementAndComputeVectorSum(vector<int> v);
void AddOneToEach(vector<int> &v);

#endif
