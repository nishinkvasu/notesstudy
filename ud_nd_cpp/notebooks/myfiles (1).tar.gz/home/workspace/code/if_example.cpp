#include <iostream>
using std::cout;

int main() 
{

    // Set a equal to true here.
    bool a = true;

    if (a) {
      cout << "Hooray! You made it into the if statement!" << "\n";
    }
}
